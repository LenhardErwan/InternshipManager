<?php
	require("src/controllers/c-main.php");
?>