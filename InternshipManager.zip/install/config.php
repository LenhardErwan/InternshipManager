<?php

//Database configuration
$database_info = array (
	"host" => "localhost",					//Path to the server database (localhost, ip or domain name)
	"port" => "5432",								//Connection port
	"name" => "InternshipManager",	//Name of the database
	"username" => "login",					//Login account
	"password" => "123456789"				//Password account
);

//Admin account
$admin_account = array(
	"last_name" => "admin",					//Last name for the admin account
	"first_name" => "admin",				//First name for the admin account
	"mail" => "admin@admin.admin",	//Mail for the admin account
	"password" => "adminadmin"			//Password for the admin account
);

?>