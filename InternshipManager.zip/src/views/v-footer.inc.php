<footer id="footer">
	<div class="footer_content">CASTEL Jeremy | LENHARD Erwan</div>
	<div class="footer_content">IUT Aix-Marseille-Universite &copy; 2019</div>
</footer> 